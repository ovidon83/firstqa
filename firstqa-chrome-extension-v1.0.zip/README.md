# FirstQA Chrome Extension - Early Access

## 🚀 Quick Start

1. **Download** this extension package
2. **Extract** the files to a folder on your computer
3. **Follow** the [INSTALLATION.md](INSTALLATION.md) guide
4. **Start analyzing** Jira and Linear tickets!

## 📋 What's Included

- ✅ **Complete Extension**: All files needed for installation
- ✅ **Installation Guide**: Step-by-step setup instructions
- ✅ **Icons**: All required extension icons
- ✅ **Full Functionality**: Jira and Linear ticket analysis

## 🔧 Installation

1. Open Chrome and go to `chrome://extensions/`
2. Enable "Developer mode" (toggle in top-right)
3. Click "Load unpacked" and select this folder
4. Start using FirstQA on Jira and Linear!

## 📞 Support

- **Email**: hello@firstqa.dev
- **GitHub**: https://github.com/ovidon83/firstqa
- **Documentation**: https://firstqa.dev/docs

---

**Version**: 1.0  
**Last Updated**: September 2024  
**Compatible**: Chrome 88+
